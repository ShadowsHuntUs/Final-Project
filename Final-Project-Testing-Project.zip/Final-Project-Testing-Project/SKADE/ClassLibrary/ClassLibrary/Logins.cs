﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Logins
    {
        public int ID { get; set; }

        public int posID { get; set; }

        public string userName { get; set; }

        public string passWord { get; set; }

        

    }
}
