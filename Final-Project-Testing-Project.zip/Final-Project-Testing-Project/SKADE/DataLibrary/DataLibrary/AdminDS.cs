﻿namespace DataLibrary
{


    partial class AdminDS
    {
    }
}
